# import

import module

import module as new_module

import module, module_2 as new_module

import module as new_module, module_2 as new_module_2


from module import func

from module import func as new_func

from module import func, func_2 as new_func_2

