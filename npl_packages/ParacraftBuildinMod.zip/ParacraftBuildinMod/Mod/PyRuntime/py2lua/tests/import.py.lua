dofile('./polyfill/pypolyfill.lua')
local module = require("module")
local new_module = require("module")
local module = require("module")
local new_module = require("module_2")
local new_module = require("module")
local new_module_2 = require("module_2")
local func = require("module").func
local new_func = require("module").func
local func = require("module").func
local new_func_2 = require("module").func_2
