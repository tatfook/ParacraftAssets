# py2lua internals

how to do transpiling work?



transpiler 运行在编译层面，运行时出现的问题它也不能解决。

用另一种语言实现语言。

不需要集成语言，而进行翻译，可以使用大部分已知的系统的功能。
