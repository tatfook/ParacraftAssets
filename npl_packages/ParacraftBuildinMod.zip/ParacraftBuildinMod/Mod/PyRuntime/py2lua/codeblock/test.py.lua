local d = dict {}
d[_to_null(nil)] = 1