invalid syntax at line 2 offset 2 in code '1x + 2x'
