# assert 断言

# 无 message
assert(1 == 1)
assert True

# 附加 message
assert 1 == 1, "one equals one"
