# pass 语句

## pass means nothing happens
i = 10
pass
assert i == 10


if True:
    pass
else:
    pass



