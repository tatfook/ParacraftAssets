local i = 10
assert((i == 10))
if true then

else

end