# while 语句

## while true
i = 0
while True:
    if i > 10:
        break
    i += 1

assert i == 11


## while and condition

i = 0
while i < 10:
    i += 1

assert i == 10
