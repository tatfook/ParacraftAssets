# variable 变量

var = 3
assert var == 3

var = var + 3
assert var == 6
