# list can't contain trailing None

d = {}

d[None] = 1

