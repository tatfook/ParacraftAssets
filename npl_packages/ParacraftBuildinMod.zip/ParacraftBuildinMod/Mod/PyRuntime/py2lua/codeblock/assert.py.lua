assert((1 == 1))
assert(true)
assert((1 == 1), "one equals one")