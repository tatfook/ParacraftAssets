# del 语句

v = "exist"
assert v

del v
# using v will cause a NameError
