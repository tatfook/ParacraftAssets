local v = "exist"
assert(v)
v = nil