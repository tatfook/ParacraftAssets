invalid syntax at line 1 offset 2 in code 'a:[]'
