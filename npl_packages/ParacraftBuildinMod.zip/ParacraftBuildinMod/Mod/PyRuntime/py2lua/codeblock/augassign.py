# augassign 自赋值

a = 1
assert a == 1

a += 2
assert a == 3

a -= 4
assert a == -1

a *= 5
assert a == -5

a /= -2
assert a == 2.5


b = 2
assert b == 2

b **= 10
assert b == 1024

b %= 3
assert b == 1

