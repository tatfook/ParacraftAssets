# constant 常量

a = True
assert a

b = False
assert not b

c = None
assert not c
