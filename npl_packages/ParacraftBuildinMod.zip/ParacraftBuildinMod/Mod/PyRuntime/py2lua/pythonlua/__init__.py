"""translator module"""
