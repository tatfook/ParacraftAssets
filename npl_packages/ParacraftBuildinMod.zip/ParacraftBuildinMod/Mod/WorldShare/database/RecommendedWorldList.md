worldType 有 server, class, world

## 全部
- name: all
- type: category

## 动画教学
- name: animation
- type: category