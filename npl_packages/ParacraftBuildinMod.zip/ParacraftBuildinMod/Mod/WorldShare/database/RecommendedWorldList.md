worldType 有 server, class, world

## 全部
- name: all
- type: category

## 动画教学
- name: animation
- type: category

### 双哈哈哈马
- worldType: server
- ip: 127.0.0.1:8099
- author: Taozi
- revision: 1
- size: 9.0
- tag: microfilm,animation
- date: 20180922

### 双马尾
- worldType: class
- classId: 6677888
- author: Taozi
- revision: 1
- size: 9.0
- tag: microfilm,animation
- date: 20180907

### 双马
- worldType: world
- url: https://git.keepwork.com/gitlab_rls_qizai/world_base32_4whyz2njvts3bpq/repository/archive.zip?ref=9241ef045f2fc2dbaa17e6a154ac9a9d4da5760a
- author: Taozi
- revision: 1
- size: 9.0
- tag: microfilm
- date: 20180906

### 双马马
- url: https://git.keepwork.com/gitlab_rls_qizai/world_base32_4whyz2njvts3bpq/repository/archive.zip?ref=9241ef045f2fc2dbaa17e6a154ac9a9d4da5760a
- author: Taozi
- revision: 1
- size: 9.0
- tag: microfilm,animation
- date: 20180906

### 双尾
- url: https://git.keepwork.com/gitlab_rls_qizai/world_base32_4whyz2njvts3bpq/repository/archive.zip?ref=9241ef045f2fc2dbaa17e6a154ac9a9d4da5760a
- author: Taozi
- revision: 1
- size: 9.0
- tag: microfilm,animation
- date: 20180905